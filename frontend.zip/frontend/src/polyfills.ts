/*
 * Polyfills
 */

// import 'zone.js/dist/zone';  // Included with Angular CLI.
import 'zone.js';