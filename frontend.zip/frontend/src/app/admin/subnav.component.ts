import { Component } from '@angular/core';

@Component({ templateUrl: 'subnav.component.html' })
export class SubNavComponent { }