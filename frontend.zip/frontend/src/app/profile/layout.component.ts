import { Component } from '@angular/core';

@Component({ templateUrl: 'layouot.component.html'})
export class LayoutComponent {}